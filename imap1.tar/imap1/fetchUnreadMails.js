var Imap = require('/usr/lib/node_modules/imap/'),
    inspect = require('util').inspect,
    htmlToText = require('/usr/lib/node_modules/html-to-text'),
    quotedPrintable = require('/usr/lib/node_modules/quoted-printable');

var imap = new Imap({
  user: 'muthu.nctu@gmail.com',
  password: 'Muthu@85',
  host: 'imap.gmail.com',
  port: 993,
  tls: true
});

function openInbox(cb) {
  imap.openBox('INBOX', false, cb);
}
 
imap.once('ready', function() {
var fs = require('fs'), fileStream;
var unreadMailCnt=0;

openInbox(function(err, box) {
  if (err) throw err;
  imap.search([ 'UNSEEN', ['SINCE', 'JAN 10, 2016'] ], function(err, results) {
    if (err) throw err;
    console.log('Unseen length : %d', results.length);
  
    //To check resultant length of unseen
    if (results.length > 0) {
      var f = imap.fetch(results, 
		{ bodies: ['HEADER.FIELDS (FROM SUBJECT)','1'], 
		struct: true,
		markSeen: true
		});

      f.on('message', function(msg, seqno) {
        console.log('Message #%d', seqno);
	var head = "";
	var headFrom = "";
	var headSubject = "";
	var text = "", text1 = "";
	var attachmentText = "";
	var attrflags = "";
	var n;
	var subStr1;

	msg.on('body', function(stream, info) {
          stream.on('data', function(chunk) {
	    if (info.which === 'HEADER.FIELDS (FROM SUBJECT)') {
              head += chunk.toString('utf8');
	    } else if (info.which === '1') {
	      text1 = chunk.toString('utf8');
 	    //text  += quotedPrintable.decode(text1);
 	      text1 = quotedPrintable.decode(text1);
	      text += htmlToText.fromString(text1);
            } else {
              attachmentText += chunk.toString('utf8');
            }  
          });
        
	  stream.once('end', function() {
	    if (info.which === 'HEADER.FIELDS (FROM SUBJECT)') {
              head = Imap.parseHeader(head);
	      headFrom = 'mail from ';
	      subStr1 = ('%s', inspect(head.from));
              n = subStr1.indexOf('<');
              n -= 3;
	      //TODO: Validate n
	      subStr1 = subStr1.substr(3, n);
	      headFrom += subStr1;
            
	      headSubject = ' Subject is ';
	      subStr1 = ('%s', inspect(head.subject));
	      n = subStr1.length;
              n -= 6;
	      //TODO: Validate n
	      subStr1 = subStr1.substr(3, n);
	      headSubject += subStr1;
            }
          });

        });
        //msg.on End

        msg.once('attributes', function(attrs) {
	  //console.log('Date: %s', inspect(attrs.date));
	  //console.log('flags: %s', inspect(attrs.flags));
	  attrflags = ('%s', inspect(attrs.flags));
        });

        msg.once('end', function() {
	  //console.log('%s', headFrom);
	  //console.log('%s', headSubject);
	  //console.log('Text: %s', inspect(text));
	  //console.log('Attachment: %s', inspect(attachmentText));

	  var textStr = ' The message content is ';
	  subStr1 = ('%s', inspect(text));
	  n = subStr1.length;
	  n -= 2;
	  //TODO: Validate n
	  subStr1 = subStr1.substr(1, n);
	  textStr += subStr1;

	  //console.log('Flags: %s\n', attrflags);
	  //console.log('Unrad mail count: %d', unreadMailCnt);

	  var outString = headFrom + headSubject + textStr;

	  //To check whether mail is unread or not
  	  unreadMailCnt++;	
	  fs.writeFile('/home/pi/imap1/Fetchedmails/' + seqno + '.txt', outString, function (err) {
  	    if (err) return console.log(err);
	  });

        });
      });

      f.once('error', function(err) {
        console.log('Fetch error: ' + err);
      });

      f.once('end', function() {
        //var str = 'You got ' + unreadMailCnt + ' unread emails';
        //fs.writeFile('/home/pi/imap1/unreadMailCnt.txt', str, function(err) {
        //  if (err) return console.log(err);
        //});
        //console.log('%s', str);
        console.log('Done fetching all messages!');
        imap.end();
      });
     } else {
	imap.end();
     } 
   //if
    });
  });

});

imap.once('error', function(err) {
  console.log(err);
});
 
imap.once('end', function() {
  console.log('Connection ended');
});
 
imap.connect();

