#!/bin/sh


for file in `find /home/pi/imap1/Fetchedmails -name "*.txt" -printf "%f\n" | sort -n`
do
  if test -f $file;  
     then 
	#echo "File: $file"; 
	cat $file > /home/pi/imap1/MailRead.txt 
        mv $file /home/pi/imap1/Processedmails/
	break;
  fi
done
