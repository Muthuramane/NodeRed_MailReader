#!/bin/sh 

arecord -D plughw:1,0 -f cd -t wav -d 2 -r 16000 /home/pi/imap1/Audio.wav

cp /home/pi/imap1/Audio.wav /home/pi/imap1/AudioListener/Audio.wav
