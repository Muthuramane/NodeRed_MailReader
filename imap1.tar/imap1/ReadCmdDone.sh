#!/bin/sh

omxplayer -p -o local /home/pi/imap1/speechAudio1.wav

echo "done" > /home/pi/imap1/ReadcmdDone.txt 
