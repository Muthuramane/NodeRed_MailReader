#!/bin/sh

sudo node /home/pi/imap1/fetchUnreadMails.js 
