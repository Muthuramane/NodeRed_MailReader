#!/bin/sh

sudo node /home/pi/imap1/fetchReadmails.js 
