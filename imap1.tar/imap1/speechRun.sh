#!/bin/sh

omxplayer -p -o local /home/pi/imap1/speechAudio.wav

echo "Unread Mail count voice done" > /home/pi/imap1/mailcntdone.txt
