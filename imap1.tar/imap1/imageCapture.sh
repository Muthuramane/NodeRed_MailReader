#!/bin/sh 

raspistill -t 2000 -w 1296 -h 972 -q 15 -vf -hf -o /home/pi/imap1/CapturedImage/testImage.jpeg
cp /home/pi/imap1/CapturedImage/testImage.jpeg /home/pi/imap1/CapturedImage/Image1.jpeg
